# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import analytic
from . import account_invoice
from . import product_pricelist
from . import product_product
from . import product_template
from . import res_company
from . import res_partner
from . import sale
from . import res_config_settings
from . import sale_layout
from . import sales_team
