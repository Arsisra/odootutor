# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from . import test_sale_to_invoice
from . import test_sale_order
from . import test_product_id_change
from . import test_sale_to_invoice_and_to_be_invoiced
